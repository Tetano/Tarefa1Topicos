package br.unitins.topicos1.model;

import java.time.LocalDate;

public class Usuario {
		public int id;
		private String nome;
		private String emai;
		private LocalDate dataNascimento;
		private String senha;
		private String sexo;
		private String cidade;
		private String perfil;
}
